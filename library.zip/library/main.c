#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
struct Book {
    char title[100];
    char author[100];
    int pages;
    int borrowed_by;
    int borrowed;
};

struct Student {
    char username[100];
    char password[100];
    int id;
    char university[100];
    char department[100];
    int fine;
};

struct Teacher {
    char username[100];
    char password[100];
    char name[100];
    char discipline[100];
};

struct Book library[100];
int numBooks = 0;

struct Student students[100];
int numStudents = 0;

struct Teacher teachers[100];
int numTeachers = 0;

void heading();
void password();
void mainmenu();
void addBook();
void deleteBook();
void searchBook();
void viewBooks();
void editBookRecord();
void manageStudents();
void editStudentRecord();
void manageTeachers();
void editTeacherRecord();
void returnBook();
void help();
void studentsLogin();
void studentsRegister();
void teachersLogin();
void teacherRegister();

void heading() {
    printf("\n\n\n\t\t***** Library Management *******\n");
    printf("\n\t\t\t** Welcome **\n\n");
}

void password() {
    heading();
    char pwd1[10] = "22";
    char pwd2[10];
    int d = 1;
    printf("\n\t\tEnter password: ");
    scanf("%s", pwd2);
    if (strcmp(pwd1, pwd2) == 0) {
        printf("\n\t\tPassword matched.\n");
        printf("\n\t\tPress any key to continue...");
        fflush(stdin);
        getchar();
    } else {
        if (d == 3) {
            exit(0);
        }
        printf("\n\t\tWrong password attempt %d\n", d);
        printf("\n\nTry again.");
        fflush(stdin);
        getchar();
        d++;
        password();
    }
}

void mainmenu() {
    system("cls");
    printf("\n\n\t\t Main menu\n");
    printf("\n\t\t 1. Add book\n");
    printf("\n\t\t 2. Delete book\n");
    printf("\n\t\t 3. Search book\n");
    printf("\n\t\t 4. View books\n");
    printf("\n\t\t 5. Edit book record\n");
    printf("\n\t\t 6. Manage students\n");
    printf("\n\t\t 7. Manage teachers\n");
    printf("\n\t\t 8. Return book\n");
    printf("\n\t\t 9. Help\n");
    printf("\n\t\t 10. Exit\n");
    printf("\n\t\t 11. Students login\n");
    printf("\n\t\t 12. Teachers login\n");
    printf("\t\t\t*\n");
    printf("\n\t\t Enter your choice: ");
    int n;
    scanf("%d", &n);
    switch (n) {
        case 1:
            addBook();
            break;
        case 2:
            deleteBook();
            break;
        case 3:
            searchBook();
            break;
        case 4:
            viewBooks();
            break;
        case 5:
            editBookRecord();
            break;
        case 6:
            manageStudents();
            break;
        case 7:
            manageTeachers();
            break;
        case 8:
            returnBook();
            break;
        case 9:
            help();
            break;
        case 10:
            exit(0);
            break;
        case 11:
            studentsLogin();
            break;
        case 12:
            teachersLogin();
            break;
        default:
            printf("\n\n\t\t Your choice is wrong!\n\n\t\t Try again.....");
            fflush(stdin);
            getchar();
            mainmenu();
    }
}
void addBook() {
    system("cls");
    printf("\n\n\t\tAdd book menu\n");

    struct Book newBook;

    printf("\n\tEnter title: ");
    getchar();
    fgets(newBook.title, sizeof(newBook.title), stdin);
    newBook.title[strcspn(newBook.title, "\n")] = '\0';

    printf("\n\tEnter author: ");
    fgets(newBook.author, sizeof(newBook.author), stdin);
    newBook.author[strcspn(newBook.author, "\n")] = '\0';

    printf("\n\tEnter number of pages: ");
    scanf("%d", &newBook.pages);

    FILE *outputFile;
    outputFile = fopen("books.txt", "a");
    if (outputFile == NULL) {
        printf("Error opening the output file.\n");
        exit(1);
    }


    fprintf(outputFile, "%s %s %d\n", newBook.title, newBook.author, newBook.pages);

    fclose(outputFile);

    printf("\nBook added successfully!\n");
    fflush(stdin);
    getchar();

    mainmenu();
}


void deleteBook() {
    system("cls");
    printf("\n\n\t\tDelete book menu\n");
    char titleToDelete[100];
    printf("\n\tEnter the title of the book to delete: ");
    scanf("%s", titleToDelete);
    int found = 0;
    FILE *inputFile, *tempFile;
    inputFile = fopen("books.txt", "r");
    tempFile = fopen("temp_books.txt", "w");
    if (inputFile == NULL || tempFile == NULL) {
        printf("Error opening files.\n");
        exit(1);
    }

    char fileTitle[100];
    while (fscanf(inputFile, "%s", fileTitle) != EOF) {
        if (strcmp(fileTitle, titleToDelete) != 0) {
            fprintf(tempFile, "%s\n", fileTitle);
        } else {
            found = 1;
        }
    }

    fclose(inputFile);
    fclose(tempFile);

    if (!found) {
        printf("\n\n\t\tBook not found!\n");
    } else {

        remove("books.txt");
        rename("temp_books.txt", "books.txt");
        printf("\nBook deleted successfully!\n");
    }

    fflush(stdin);
    getchar();
    mainmenu();
}

void searchBook() {
    system("cls");
    printf("\n\n\t\tSearch book menu\n");
    char titleToSearch[100];
    printf("\n\tEnter the title of the book to search: ");
    scanf("%s", titleToSearch);
    int found = 0;

    FILE *inputFile;
    inputFile = fopen("books.txt", "r");
    if (inputFile == NULL) {
        printf("Error opening the input file.\n");
        exit(1);
    }

    char fileTitle[100];
    while (fscanf(inputFile, "%s", fileTitle) != EOF) {
        if (strcmp(fileTitle, titleToSearch) == 0) {
            printf("\n\tBook found!\n");
            found = 1;
            break;
        }
    }

    fclose(inputFile);

    if (!found) {
        printf("\n\tBook not found.\n");
    }

    fflush(stdin);
    getchar();
    mainmenu();
}

void viewBooks() {
    system("cls");
    printf("\n\n\t\tBooks in library:\n");

    FILE *inputFile;
    inputFile = fopen("books.txt", "r");
    if (inputFile == NULL) {
        printf("Error opening the input file.\n");
        exit(1);
    }

    char title[100], author[100];
    int pages;

    while (fscanf(inputFile, "%s %s %d", title, author, &pages) != EOF) {
        printf("\n\tTitle: %s\n", title);
        printf("\tAuthor: %s\n", author);
        printf("\tPages: %d\n", pages);
    }

    fclose(inputFile);

    fflush(stdin);
    getchar();
    mainmenu();
}

void editBookRecord() {
    system("cls");
    printf("\n\n\t\tEdit book record menu\n");
    char titleToEdit[100];
    printf("\n\tEnter the title of the book to edit: ");
    scanf("%s", titleToEdit);
    int found = 0;

    FILE *file;
    file = fopen("books.txt", "r+");
    if (file == NULL) {
        printf("Error opening the file.\n");
        exit(1);
    }

    struct Book tempBook;
    while (fscanf(file, "%s %s %d", tempBook.title, tempBook.author, &tempBook.pages) != EOF) {
        if (strcmp(tempBook.title, titleToEdit) == 0) {
            printf("\n\tEnter new title: ");
            scanf("%s", tempBook.title);
            printf("\tEnter new author: ");
            scanf("%s", tempBook.author);
            printf("\tEnter new number of pages: ");
            scanf("%d", &tempBook.pages);
            fseek(file, -1 * (int)sizeof(struct Book), SEEK_CUR);
            fprintf(file, "%s %s %d", tempBook.title, tempBook.author, tempBook.pages);
            printf("\n\tBook record updated successfully!\n");
            found = 1;
            break;
        }
    }

    fclose(file);

    if (!found)
        printf("\n\tBook not found!\n");

    fflush(stdin);
    getchar();
    mainmenu();
}

void manageStudents() {
    system("cls");
    printf("\n\n\t\tManage students menu\n");
    int choice;
    printf("\n\t1. Add student\n");
    printf("\t2. Edit student record\n");
    printf("\t3. Return to main menu\n");
    printf("\nEnter your choice: ");
    scanf("%d", &choice);
    switch (choice) {
        case 1:
            studentsRegister();
            break;
        case 2:
            editStudentRecord();
            break;
        case 3:
            mainmenu();
            break;
        default:
            printf("\nInvalid choice!\n");
            break;
    }
}

void manageTeachers() {
    system("cls");
    printf("\n\n\t\tManage teachers menu\n");
    int choice;
    printf("\n\t1. Add teacher\n");
    printf("\t2. Edit teacher record\n");
    printf("\t3. Return to main menu\n");
    printf("\nEnter your choice: ");
    scanf("%d", &choice);
    switch (choice) {
        case 1:
            teacherRegister();
            break;
        case 2:
            editTeacherRecord();
            break;
        case 3:
            mainmenu();
            break;
        default:
            printf("\nInvalid choice!\n");
            break;
    }
}

void editStudentRecord() {
    system("cls");
    printf("\n\n\t\tEdit student record menu\n");
    int id;
    printf("\nEnter student ID to edit: ");
    scanf("%d", &id);
    int found = 0;

    FILE *file;
    file = fopen("students.txt", "r+");
    if (file == NULL) {
        printf("Error opening the file.\n");
        exit(1);
    }

    while (fscanf(file, "%s %s %d %s %s %d", students[numStudents].username, students[numStudents].password,
                  &students[numStudents].id, students[numStudents].university, students[numStudents].department,
                  &students[numStudents].fine) != EOF) {
        if (students[numStudents].id == id) {
            printf("\nEnter new username: ");
            scanf("%s", students[numStudents].username);
            printf("\nEnter new password: ");
            scanf("%s", students[numStudents].password);
            printf("\nEnter new university name: ");
            scanf("%s", students[numStudents].university);
            printf("\nEnter new department name: ");
            scanf("%s", students[numStudents].department);
            fseek(file, -1 * (int)sizeof(struct Student), SEEK_CUR);
            fprintf(file, "%s %s %d %s %s %d", students[numStudents].username, students[numStudents].password,
                    students[numStudents].id, students[numStudents].university, students[numStudents].department,
                    students[numStudents].fine);
            printf("\nStudent record updated successfully!\n");
            found = 1;
            break;
        }
    }

    fclose(file);

    if (!found)
        printf("\nStudent ID not found!\n");

    fflush(stdin);
    getchar();
    mainmenu();
}

void editTeacherRecord() {
    system("cls");
    printf("\n\n\t\tEdit teacher record menu\n");
    char username[100];
    printf("\nEnter teacher username to edit: ");
    scanf("%s", username);
    int found = 0;
    for (int i = 0; i < numTeachers; i++) {
        if (strcmp(teachers[i].username, username) == 0) {
            printf("\nEnter new name: ");
            scanf("%s", teachers[i].name);
            printf("\nEnter new discipline: ");
            scanf("%s", teachers[i].discipline);
            printf("\nTeacher record updated successfully!\n");
            found = 1;
            break;
        }
    }
    if (!found)
        printf("\nTeacher username not found!\n");

    fflush(stdin);
    getchar();
    mainmenu();
}

void returnBook() {
    system("cls");
    printf("\n\n\t\tReturn book menu\n");
    char titleToReturn[100];
    printf("\nEnter the title of the book to return: ");
    scanf("%s", titleToReturn);
    int found = 0;
    for (int i = 0; i < numBooks; i++) {
        if (strcmp(library[i].title, titleToReturn) == 0) {
            if (library[i].borrowed) {
                library[i].borrowed = 0;
                printf("\nBook returned successfully!\n");
            } else {
                printf("\nThis book is not currently borrowed!\n");
            }
            found = 1;
            break;
        }
    }
    if (!found)
        printf("\nBook not found!\n");

    fflush(stdin);
    getchar();
    mainmenu();
}

void help() {
    printf("\n\n\t\tHelp menu\n");
    printf("need any help?\n\tcontact:01964267101");
    fflush(stdin);
    getchar();
    mainmenu();
}

void studentsLogin() {
    char username[100];
    char password[100];
    printf("\n\n\t\tStudents login\n");
    printf("\nEnter username: ");
    scanf("%s", username);
    printf("Enter password: ");
    scanf("%s", password);


    FILE *file;
    file = fopen("students.txt", "r");
    if (file == NULL) {
        printf("Error opening the file.\n");
        exit(1);
    }

    int found = 0;
    while (fscanf(file, "%s %s %d %s %s %d", students[numStudents].username, students[numStudents].password,
                  &students[numStudents].id, students[numStudents].university, students[numStudents].department,
                  &students[numStudents].fine) != EOF) {
        if (strcmp(students[numStudents].username, username) == 0) {

            if (strcmp(students[numStudents].password, password) == 0) {

                printf("\nLogin successful!\n");
                found = 1;
                break;
            } else {

                printf("\nIncorrect password!\n");
                found = 1;
                break;
            }
        }
        numStudents++;
    }

    fclose(file);

    if (!found) {

        printf("\nUsername not found!\n");
    } else {
        // Display student's information
        printf("\nStudent Information:\n");
        printf("Username: %s\n", students[numStudents].username);
        printf("ID: %d\n", students[numStudents].id);
        printf("University: %s\n", students[numStudents].university);
        printf("Department: %s\n", students[numStudents].department);
        printf("Fine: %d\n", students[numStudents].fine);


        printf("\nAvailable Books in Library:\n");
        viewBooks();
    }

    fflush(stdin);
    getchar();
    mainmenu();
}

void studentsRegister() {
    printf("\n\n\t\tRegister Student\n");
    printf("Enter username: ");
    scanf("%s", students[numStudents].username);
    printf("Enter password: ");
    scanf("%s", students[numStudents].password);
    printf("Enter ID: ");
    scanf("%d", &students[numStudents].id);
    printf("Enter university name: ");
    scanf("%s", students[numStudents].university);
    printf("Enter department name: ");
    scanf("%s", students[numStudents].department);
    students[numStudents].fine = 0;
    numStudents++;

    FILE *file;
    file = fopen("students.txt", "a");
    if (file == NULL) {
        printf("Error opening the file.\n");
        exit(1);
    }


    fprintf(file, "%s %s %d %s %s %d\n", students[numStudents - 1].username, students[numStudents - 1].password,
            students[numStudents - 1].id, students[numStudents - 1].university, students[numStudents - 1].department,
            students[numStudents - 1].fine);

    fclose(file);

    printf("Student registered successfully!\n");
    fflush(stdin);
    getchar();
    mainmenu();
}


void teachersLogin() {
    char username[100];
    char password[100];
    printf("\n\n\t\tTeachers login\n");
    printf("Enter username: ");
    scanf("%s", username);
    printf("Enter password: ");
    scanf("%s", password);

    FILE *file;
    file = fopen("teachers.txt", "r");
    if (file == NULL) {
        printf("Error opening the file.\n");
        exit(1);
    }

    int found = 0;
    while (fscanf(file, "%s %s %s %s", teachers[numTeachers].username, teachers[numTeachers].password,
                  teachers[numTeachers].name, teachers[numTeachers].discipline) != EOF) {
        if (strcmp(teachers[numTeachers].username, username) == 0) {
            if (strcmp(teachers[numTeachers].password, password) == 0) {
                printf("\nLogin successful!\n");
                found = 1;
                break;
            } else {
                printf("\nIncorrect password!\n");
                found = 1;
                break;
            }
        }
        numTeachers++;
    }

    fclose(file);

    if (!found) {
        printf("\nUsername not found!\n");
    } else {
        printf("\nTeacher Information:\n");
        printf("Username: %s\n", teachers[numTeachers].username);
        printf("Name: %s\n", teachers[numTeachers].name);
        printf("Discipline: %s\n", teachers[numTeachers].discipline);

        printf("\nEnter the title of the book to borrow: ");
        char titleToBorrow[100];
        scanf("%s", titleToBorrow);
        int foundBook = 0;
        for (int i = 0; i < numBooks; i++) {
            if (strcmp(library[i].title, titleToBorrow) == 0) {
                foundBook = 1;
                library[i].borrowed = 1;
                time_t now = time(NULL);
                struct tm *borrowDate = localtime(&now);
                struct tm returnDate = *borrowDate;
                returnDate.tm_mon += 6;
                mktime(&returnDate);
                printf("Book '%s' borrowed successfully. Return by: %d-%02d-%02d\n",
                       library[i].title, returnDate.tm_year + 1900, returnDate.tm_mon + 1, returnDate.tm_mday);
                break;
            }
        }
        if (!foundBook) {
            printf("Book not found!\n");
        }
    }
}


void teacherRegister() {
    printf("\n\n\t\tRegister Teacher\n");
    printf("Enter username: ");
    scanf("%s", teachers[numTeachers].username);
    printf("Enter password: ");
    scanf("%s", teachers[numTeachers].password);
    printf("Enter name: ");
    scanf("%s", teachers[numTeachers].name);
    printf("Enter discipline: ");
    scanf("%s", teachers[numTeachers].discipline);
    numTeachers++;

    FILE *file;
    file = fopen("teachers.txt", "a");
    if (file == NULL) {
        printf("Error opening the file.\n");
        exit(1);
    }

    fprintf(file, "%s %s %s %s\n", teachers[numTeachers - 1].username, teachers[numTeachers - 1].password,
            teachers[numTeachers - 1].name, teachers[numTeachers - 1].discipline);

    fclose(file);

    printf("Teacher registered successfully!\n");
    fflush(stdin);
    getchar();
    mainmenu();
}

int main() {
    int n;

    heading();

    printf("\n\n\t\t1.Log in as student:");
    printf("\n\n\t\t2.Log in as teacher:");
    printf("\n\n\t\t3.Log in as librarian:");
     printf("\nyour choice:");
    scanf("%d", &n);

    switch (n) {
        case 1:
            studentsLogin();
            break;
        case 2:
            teachersLogin();
            break;
        case 3:
            password();
            mainmenu();
            break;
        default:
            printf("\n\n\t\tYour choice is wrong!\n\n\t\tTry again.....");
            getchar();

            break;
    }

    return 0;
}
